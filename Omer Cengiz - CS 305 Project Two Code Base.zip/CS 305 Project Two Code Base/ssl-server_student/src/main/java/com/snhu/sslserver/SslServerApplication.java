package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
	@RestController
    public static class ChecksumController {

        @GetMapping("/checksum")
        public String getChecksum() {
            try {
                // Unique data string
                String data = "Hello World Check Sum!";
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(data.getBytes());

                // Using Tomcat's HexUtils to convert hash to hex
                String checksum = HexUtils.toHexString(hash);

                // Return output
                return "<html>" +
                        "<body>" +
                        "<h3>Name: Omer Cengiz</h3>" +
                        "<h3>Data: " + data + "</h3>" +
                        "<h3>Checksum: " + checksum + "</h3>" +
                        "</body>" +
                        "</html>";
            } catch (NoSuchAlgorithmException e) {
                return "Error computing checksum: " + e.getMessage();
            }
        }
    }
	
}
